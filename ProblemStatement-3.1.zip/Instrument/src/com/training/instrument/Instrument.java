package com.training.instrument;

import java.util.Random;

public abstract class Instrument {
	public abstract void play();
}
