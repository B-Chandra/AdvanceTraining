package com.training.book;

public class Main {
	public void createBooks() {
		Book b[] = new Book[2];		 
	      b[0] = new Book("Java Programing ", 350.50);
	      b[1] = new Book("Let Us C", 200.00);
	      for(int i = 0; i<b.length; i++) {
		         b[i].display();
		         System.out.println("  ");
	      }
	    
	      }
	
	public void showBooks() {
		  	createBooks();
		
	}
	public static void main(String args[])  {
	    Main a = new Main();  
		a.showBooks();
	   
	      }
}
