package com.training.numbers;

public class SumOfTwoNumbers {
	public static void main(String[] args) {

	    int i = 1, n = 13, first = 1, second = 3;
	    System.out.println("first "+first +" second "+second);

	    while (i <= n) {
	      System.out.print(first + ", ");

	      int next = first + second;
	      first = second;
	      second = next;

	      i++;
	    }
	  }
}
