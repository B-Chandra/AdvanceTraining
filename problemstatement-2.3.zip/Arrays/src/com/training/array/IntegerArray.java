package com.training.array;

import java.util.ArrayList;
import java.util.Arrays;

public class IntegerArray {
	public static void main(String[] args) {    
        int arr [] = new int [] {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2};  
        int sum = 0;  
         
        for (int i = 0; i < arr.length; i++) {  
           sum = sum + arr[i];  
        } 
        int newArr[] = new int[arr.length+1];  
        int value = sum; 
        for(int i = 0; i<arr.length; i++) {  
        	newArr[i] = arr[i];  
        }  
        newArr[arr.length] = value;  
        System.out.println(Arrays.toString(newArr));  
    
        
        
        
    }  
}
